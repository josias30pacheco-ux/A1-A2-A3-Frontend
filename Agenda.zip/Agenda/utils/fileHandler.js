const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../data/contacts.json');

// Leer contactos desde JSON
function readContacts() {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify([]));
  }
  const data = fs.readFileSync(filePath, 'utf8');
  return JSON.parse(data);
}

// Guardar contactos en JSON
function writeContacts(contacts) {
  fs.writeFileSync(filePath, JSON.stringify(contacts, null, 2));
}

module.exports = { readContacts, writeContacts };
