const express = require('express');
const bodyParser = require('body-parser');
const contactsRoutes = require('./routes/contacts');

const app = express();
const PORT = 3000;

// Middleware para procesar JSON
app.use(bodyParser.json());

// Rutas
app.use('/api/contacts', contactsRoutes);

// Servidor escuchando
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
