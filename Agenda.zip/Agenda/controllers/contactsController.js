const { v4: uuidv4 } = require('uuid');
const Contact = require('../models/contact');
const { readContacts, writeContacts } = require('../utils/fileHandler');

// Obtener todos los contactos
function getAllContacts(req, res) {
  const contacts = readContacts();
  res.json(contacts);
}

// Obtener contacto por ID
function getContactById(req, res) {
  const contacts = readContacts();
  const contact = contacts.find(c => c.id === req.params.id);
  if (!contact) return res.status(404).json({ message: "Contacto no encontrado" });
  res.json(contact);
}

// Crear un contacto
function createContact(req, res) {
  const { name, email, phone } = req.body;
  const contacts = readContacts();
  const newContact = new Contact(uuidv4(), name, email, phone);
  contacts.push(newContact);
  writeContacts(contacts);
  res.status(201).json(newContact);
}

// Actualizar contacto
function updateContact(req, res) {
  const contacts = readContacts();
  const contactIndex = contacts.findIndex(c => c.id === req.params.id);
  if (contactIndex === -1) return res.status(404).json({ message: "Contacto no encontrado" });

  const updatedContact = { ...contacts[contactIndex], ...req.body };
  contacts[contactIndex] = updatedContact;
  writeContacts(contacts);
  res.json(updatedContact);
}

// Eliminar contacto
function deleteContact(req, res) {
  const contacts = readContacts();
  const filteredContacts = contacts.filter(c => c.id !== req.params.id);
  if (contacts.length === filteredContacts.length) {
    return res.status(404).json({ message: "Contacto no encontrado" });
  }
  writeContacts(filteredContacts);
  res.json({ message: "Contacto eliminado" });
}

module.exports = { getAllContacts, getContactById, createContact, updateContact, deleteContact };
